## Step-1

![image info](./1.png)

## Step-2

![image info](./2.jpeg)

## Step-3

![image info](./3.png)

## Step-4

![image info](./4.png)

## Step-5

![image info](./5.png)

## Step-6

![image info](./6.png)

## Step-7

![image info](./7.png)

## Step-8

![image info](./8.png)

## Step-9

![image info](./9.png)

## Step-10

![image info](./10.png)

## Step-11

![image info](./11.png)

## Step-12

![image info](./12.png)

## Your Audio Stored Here

![image info](./13.jpeg)
